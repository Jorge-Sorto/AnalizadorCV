"""CV Job Analyzer application."""
